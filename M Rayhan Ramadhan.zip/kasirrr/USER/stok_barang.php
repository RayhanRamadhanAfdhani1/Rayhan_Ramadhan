<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Barang</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Tambahkan link untuk ikon Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #2980b9; /* Warna latar belakang */
            color: #fff;
        }

        #header {
            padding: 20px;
            text-align: center;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            margin-bottom: 20px;
            position: relative;
        }

        #header::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('your-ornament-image.jpg') repeat;
            opacity: 0.2;
            top: 0;
            left: 0;
            z-index: -1;
        }

        #welcome {
            font-size: 28px;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff; /* Warna latar belakang tabel */
            color: #2980b9; /* Warna teks pada tabel */
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #3498db;
            color: #fff;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #1f618d;
        }

        .fa {
            margin-right: 5px;
        }

        a i {
            color: #3498db;
            transition: color 0.3s ease;
        }

        a:hover i {
            color: #1f618d;
        }
    </style>
</head>

<body>

    <div id="header">
        <div id="welcome">
            <h2>Stock Barang</h2>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <button class="btn btn-primary mb-2" onclick="location.href='user_dashboard.php'"><i class="fas fa-arrow-left"></i> Kembali ke Halaman Utama</button>
                <button class="btn btn-success mb-2" onclick="location.href='tambah_produk.php'"><i class="fas fa-plus"></i> Tambah Produk Baru</button>
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ProdukID</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        session_start();
                        include 'config.php';
                        $sql = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk";
                        $result = mysqli_query($conn, $sql);
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row["ProdukID"] . "</td>";
                                echo "<td>" . $row["NamaProduk"] . "</td>";
                                echo "<td>" . $row["Harga"] . "</td>";
                                echo "<td>" . $row["Stok"] . "</td>";
                                echo "<td>";
                                echo "<a href='edit_produk.php?id=" . $row["ProdukID"] . "' title='Edit'><i class='fas fa-edit'></i></a>&nbsp;|&nbsp;";
                                echo "<a href='hapus_produk.php?id=" . $row["ProdukID"] . "' title='Hapus'><i class='fas fa-trash-alt'></i></a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>0 hasil</td></tr>";
                        }
                        mysqli_close($conn);
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>
