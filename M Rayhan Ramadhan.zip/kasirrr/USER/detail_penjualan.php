<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin: 0 auto;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background-color: #343a40;
            color: white;
        }

        tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <h2>Detail Penjualan</h2>

    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                
                <th>PenjualanID</th>
                <th>Nama Produk</th>
                <th>JumlahProduk</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <!-- Isi tabel dengan data dari database menggunakan PHP -->
            <?php
            include 'config.php';
            $sql = "SELECT detailpenjualan.DetailID, detailpenjualan.PenjualanID, produk.NamaProduk, detailpenjualan.JumlahProduk, detailpenjualan.Subtotal FROM detailpenjualan INNER JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['PenjualanID'] . "</td>";
                    echo "<td>" . $row['NamaProduk'] . "</td>";
                    echo "<td>" . $row['JumlahProduk'] . "</td>";
                    echo "<td>" . $row['Subtotal'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>Tidak ada data detail penjualan.</td></tr>";
            }
            mysqli_close($conn);
            ?>
        </tbody>
    </table>

    <!-- Tombol untuk kembali ke halaman dashboard -->
    <a href="user_dashboard.php" class="btn btn-primary">Kembali ke Dashboard</a>

</body>

</html>
