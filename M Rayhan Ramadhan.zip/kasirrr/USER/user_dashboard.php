<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('pemandangan.jpg');
            background-size: cover;
            color: #ecf0f1;
        }

        .navbar {
            background-color: rgba(0, 123, 255, 0.7);
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            padding: 20px 0;
            animation: slideInDown 0.5s ease;
        }

        @keyframes slideInDown {
            from {
                transform: translateY(-100%);
            }

            to {
                transform: translateY(0);
            }
        }

        .navbar-brand {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center; /* Menyatukan gambar dan teks secara vertikal */
        }

        .navbar-brand img {
            width: 40px; /* Lebar foto profil */
            height: 40px; /* Tinggi foto profil */
            border-radius: 50%; /* Mengubah foto profil menjadi lingkaran */
            margin-right: 10px; /* Jarak antara foto profil dan teks */
        }

        .navbar-nav .nav-item .nav-link {
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-item .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.3);
            color: #ff0;
            text-shadow: 2px 2px 5px rgba(255, 255, 255, 0.8);
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="p.png" alt="Foto Profil" class="mr-2">
                Selamat Datang Petugas
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="pembelian.php">Pembelian</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="stok_barang.php">Stok Barang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="detail_penjualan.php">Detail Penjualan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
