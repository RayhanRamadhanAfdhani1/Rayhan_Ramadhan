<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Pelanggan Baru</title>
<style>
 body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #3498db;
    color: #fff;
}

#header {
    padding: 20px;
    text-align: center;
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    margin-bottom: 20px;
    position: relative;
}

#header::before {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    background: url('your-ornament-image.jpg') repeat;
    opacity: 0.2;
    top: 0;
    left: 0;
    z-index: -1;
}

#welcome {
    font-size: 28px;
    font-weight: bold;
}

form {
    max-width: 400px;
    margin: 0 auto;
    background-color: rgba(236, 240, 241, 0.8); /* Menyesuaikan tingkat transparansi */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #3498db;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #333;
}

input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-bottom: 16px;
    box-sizing: border-box;
}

button {
    background-color: #3498db;
    color: #fff;
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    margin-bottom: 10px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #1f618d;
}


</style>
</head>
<body>

<h2>Tambah Pelanggan Baru</h2>

<form action="proses_tambah_pelanggan.php" method="POST">
  <label for="id_pelanggan">ID Pelanggan:</label><br>
  <input type="text" id="id_pelanggan" name="id_pelanggan"><br><br>
  
  <label for="nama_pelanggan">Nama Pelanggan:</label><br>
  <input type="text" id="nama_pelanggan" name="nama_pelanggan"><br><br>
  
  <label for="alamat">Alamat:</label><br>
  <input type="text" id="alamat" name="alamat"><br><br>
  
  <label for="nomor_telepon">Nomor Telepon:</label><br>
  <input type="text" id="nomor_telepon" name="nomor_telepon"><br><br>
  
  <button type="submit">Tambah Pelanggan</button>
</form>

</body>
</html>
