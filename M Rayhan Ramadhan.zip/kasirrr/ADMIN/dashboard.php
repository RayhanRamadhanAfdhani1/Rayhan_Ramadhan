<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('pemandangan.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: #343a40;
            margin: 0;
            padding: 0;
            height: 100vh; /* Tinggi 100% dari viewport */
        }

        .navbar {
            background-color: rgba(0, 123, 255, 0.5); /* Warna latar belakang dengan opacity */
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            padding: 20px 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Efek bayangan */
            animation: slideDown 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94); /* Animasi masuk */
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .navbar-brand {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center; /* Menyatukan gambar dan teks secara vertikal */
        }

        .navbar-brand img {
            width: 40px; /* Lebar foto profil */
            height: 40px; /* Tinggi foto profil */
            border-radius: 50%; /* Mengubah foto profil menjadi lingkaran */
            margin-right: 10px; /* Jarak antara foto profil dan teks */
        }

        .navbar-brand:hover {
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.8); /* Efek shadow teks muncul saat hover */
        }

        .navbar-nav .nav-item .nav-link {
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-item .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.3); /* Warna latar belakang tautan saat dihover dengan opacity */
            color: #ff0; /* Ganti warna teks saat hover */
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.8); /* Efek shadow teks muncul saat hover */
        }

        .navbar-nav .nav-item.active .nav-link {
            background-color: rgba(255, 255, 255, 0.2); /* Warna latar belakang tautan aktif dengan opacity */
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="profil.png" alt="Foto Profil" class="mr-2"> Selamat Datang Admin
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="pembelian.php">Pembelian</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="stok_barang.php">Stok Barang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="detail_penjualan.php">Detail Penjualan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../register.php">Register</a>
                    </li>
                    <?php if(isset($_SESSION['level']) && $_SESSION['level'] == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="data_petugas.php">Data Petugas</a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
